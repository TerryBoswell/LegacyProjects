﻿
namespace Scribe.Connector.etouches
{
    public class StandardConnectorSettings
    {
        public const string SettingsUITypeName = "";
        public const string SettingsUIVersion = "1.0";
        public const string ConnectionUITypeName = "ScribeOnline.GenericConnectionUI";
        public const string ConnectionUIVersion = "1.0";
        public const string XapFileName = "ScribeOnline";

    }
}
