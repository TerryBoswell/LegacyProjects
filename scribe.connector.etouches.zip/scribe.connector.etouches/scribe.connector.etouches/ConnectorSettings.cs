﻿
namespace Scribe.Connector.etouches
{
    public class ConnectorSettings
    {
        public const string ConnectorTypeId = "{A9EDFF50-7F40-4346-8011-86EE8473BDB3}";
        public const string ConnectorVersion = "1.0.2";
        public const string Description = "etouches Scribe Connector";
        public const string Name = "etouches";
        public const bool SupportsCloud = true;

    }
}
