﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Scribe.Connector.Cdk.Sample.Rest.Sys.Test
{
	[TestClass]
	public class GoToWebinarClientTest
	{
		
	}
}
