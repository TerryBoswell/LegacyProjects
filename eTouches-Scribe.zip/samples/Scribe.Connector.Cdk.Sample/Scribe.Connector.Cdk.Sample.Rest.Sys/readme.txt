System.Linq.Dynamic.cs
Copyright Microsoft
Distributed with permission